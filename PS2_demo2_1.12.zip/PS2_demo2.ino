#include <Servo.h>
#include <Wire.h>
#include "MS5837.h"
#include "PIDController.h"
#include <PS2X_lib.h>  // 包含PS2X库，用于v1.6版本

/******************************************************************
 * 设置连接到PS2控制器的引脚：
 *******************************************************************/
#define PS2_DAT        13  // 数据引脚
//#define PS2_CMD        11  // 命令引脚
//#define PS2_SEL        10  // 选择引脚
#define PS2_CMD        8  // 命令引脚
#define PS2_SEL        2  // 选择引脚
#define PS2_CLK        12  // 时钟引脚

/******************************************************************
 * 选择PS2控制器的模式：
 *******************************************************************/
#define pressures   true  // 开启按键压力模式
#define rumble      false  // 关闭马达震动功能

PS2X ps2x; // 创建PS2控制器类实例




int error = 0;  // 错误代码
byte type = 0;  // 控制器类型
byte vibrate = 0;  // 马达震动强度

MS5837 sensor;





// 定义舵机对象
Servo myServo1; // 1号电机
Servo myServo2; // 2号电机
Servo myServo3; // 3号电机




// 定义PID控制器参数
float Kp = 1.0, Ki = 0.0, Kd = 0.05;
PIDController depthController(Kp, Ki, Kd);
// 定义目标深度和当前深度
float setPointDepth = 0.5;
float currentDepth = 0.0;
float adjustment = 0.0;



// 定义舵机位置变量
int servoPosition1 = 1500; // 1号电机位置
int servoPosition2 = 1500; // 2号电机位置
int servoPosition3 = 1500; // 3号电机位置
int mode = 1;




int pos1 = 0;
int pos2 = 0;
Servo myservo1;  // 创建第一个舵机对象
Servo myservo2;  // 创建第二个舵机对象



void setup() {

  Serial.begin(9600);



  myservo1.attach(9, 500, 2500);  // 将第一个舵机绑定到引脚9
  myservo2.attach(10, 500, 2500); // 将第二个舵机绑定到引脚10




  delay(500);  // 增加延迟，给无线PS2模块启动时间，然后配置

  // 设置引脚和设置：GamePad(时钟, 命令, 注意, 数据, 压力?, 震动?) 检查错误
  error = ps2x.config_gamepad(PS2_CLK, PS2_CMD, PS2_SEL, PS2_DAT, pressures, rumble);
  if(error == 0){
    Serial.println("Found Controller, configured successful");
    Serial.print("pressures = ");
    Serial.println(pressures ? "true" : "false");
    Serial.print("rumble = ");
    Serial.println(rumble ? "true" : "false");
  } else {
    Serial.println("Error configuring PS2 controller");
  }

  type = ps2x.readType();
  switch(type) {
    case 0:
      Serial.println("Unknown Controller type found");
      break;
    case 1:
      Serial.println("DualShock Controller found");
      break;
    case 2:
      Serial.println("GuitarHero Controller found");
      break;
    case 3:
      Serial.println("Wireless Sony DualShock Controller found");
      break;
  }

  Wire.begin();


  // 初始化压力传感器
  sensor.init();
  sensor.setModel(MS5837::MS5837_02BA);
  sensor.setFluidDensity(997);



  myServo1.attach(3);
  myServo2.attach(5);
  myServo3.attach(6);

  // 初始化舵机位置
  myServo1.writeMicroseconds(1500);
  myServo2.writeMicroseconds(1500);
  myServo3.writeMicroseconds(1500);
}

void loop() {
  // 读取PS2控制器的状态
  ps2x.read_gamepad(false, vibrate);

  // 检测绿色和红色按钮并打印消息
  if(ps2x.Button(YELLOW_FRET))//变速运动模式
  //这里有点问题，黄色和绿色的按键好像反了，这里按红色就好了
   {
    Serial.println("Green Fret Pressed mode = 1");
    mode = 1;
  }
  if(ps2x.Button(RED_FRET))//导流板运动模式 
  {
    Serial.println("Red Fret Pressed mode = 2");
    mode = 2;
  }
  if(ps2x.Button(BLUE_FRET))//上下潜模式 
  {
    Serial.println("Red Fret Pressed mode = 3");
    mode = 3;
  }


  // 输出遥控器数据
  if(ps2x.Button(PSB_SELECT))
    Serial.println("Select is being held");
  if(ps2x.Button(PSB_START))
    Serial.println("Start is being held");
    
if(mode == 1)
{
  // 控制上下电机
  int rxValue = ps2x.Analog(PSS_RX);
  if (abs(rxValue - 127) > 30) { // 添加死区
    servoPosition3 = 1500 + (rxValue - 127);
  } else {
    servoPosition3 = 1500;
  }

  // 控制前进和后退电机
  //右电机控制
  int ryValue = ps2x.Analog(PSS_RY);
  if (abs(ryValue - 127) > 30) { // 添加死区
    servoPosition1 = 1500 + (ryValue - 127);
  } else {
    servoPosition1 = 1500;
  }

  //左电机控制
  int lyValue = ps2x.Analog(PSS_LY);
  if (abs(lyValue - 127) > 30) { // 添加死区
    servoPosition2 = 1500 + (lyValue - 127);
  } else {
    servoPosition2 = 1500;
  }

  // 限制舵机位置值，确保它们在1000到2000之间
  servoPosition1 = constrain(servoPosition1, 1030, 1970);
  servoPosition2 = constrain(servoPosition2, 1030, 1970);
  servoPosition3 = constrain(servoPosition3, 1030, 1970);

  // 应用舵机位置
  myServo1.writeMicroseconds(servoPosition1);
  myServo2.writeMicroseconds(servoPosition2);
  myServo3.writeMicroseconds(servoPosition3);
}

if(mode == 2)
{
  /*
for (pos = 0; pos <= 180; pos += 1) {       //pos+=1等价于pos=pos+1
    myservo.write(pos);
    delay(15);					
  }
  for (pos = 180; pos >= 0; pos -= 1) {
    myservo.write(pos);
    delay(15); 					
  }
  */
  int rxValue = ps2x.Analog(PSS_RX);

 //   pos1 =  (rxValue - 127)*1.5;
pos1 =  200;
  myservo1.write(pos1);

    int lxValue = ps2x.Analog(PSS_LX);

//    pos2 =  (lxValue - 127)*1.5;
pos2 =  lxValue;
  myservo2.write(pos2);


  // 控制前进和后退电机
  //右电机控制
  int ryValue = ps2x.Analog(PSS_RY);
  if (abs(ryValue - 127) > 30) { // 添加死区
    servoPosition1 = 1500 + (ryValue - 127);
  } else {
    servoPosition1 = 1500;
  }
  //左电机控制
  int lyValue = ps2x.Analog(PSS_LY);
  if (abs(lyValue - 127) > 30) { // 添加死区
    servoPosition2 = 1500 + (lyValue - 127);
  } else {
    servoPosition2 = 1500;
  }

  // 限制舵机位置值，确保它们在1000到2000之间
  servoPosition1 = constrain(servoPosition1, 1030, 1970);
  servoPosition2 = constrain(servoPosition2, 1030, 1970);
  servoPosition3 = constrain(servoPosition3, 1030, 1970);

  // 应用舵机位置
  myServo1.writeMicroseconds(servoPosition1);
  myServo2.writeMicroseconds(servoPosition2);
  myServo3.writeMicroseconds(servoPosition3);
}

if(mode == 3)
{
/*
  int rxValue = ps2x.Analog(PSS_RX);

    pos2 =  (rxValue - 127)*2;

  myservo2.write(pos2);

/*
  // 控制前进和后退电机
  //右电机控制
  int ryValue = ps2x.Analog(PSS_RY);
  if (abs(ryValue - 127) > 30) { // 添加死区
    servoPosition1 = 1500 + (ryValue - 127);
  } else {
    servoPosition1 = 1500;
  }
  //左电机控制
  int lyValue = ps2x.Analog(PSS_LY);
  if (abs(lyValue - 127) > 30) { // 添加死区
    servoPosition2 = 1500 + (lyValue - 127);
  } else {
    servoPosition2 = 1500;
  }
*/
    sensor.read();
    currentDepth = sensor.depth();
   float adjustment = depthController.update(setPointDepth, currentDepth);
    servoPosition1 = 1500 + adjustment*200;
    servoPosition2 = 1500 + adjustment*200;



  // 限制舵机位置值，确保它们在1000到2000之间
  servoPosition1 = constrain(servoPosition1, 1030, 1970);
  servoPosition2 = constrain(servoPosition2, 1030, 1970);
  servoPosition3 = constrain(servoPosition3, 1030, 1970);

  // 应用舵机位置
  myServo1.writeMicroseconds(servoPosition1);
  myServo2.writeMicroseconds(servoPosition2);
  myServo3.writeMicroseconds(servoPosition3);



    // 调试输出
    Serial.print("Target Depth: ");
    Serial.print(setPointDepth, 2);
    Serial.print(" m, Current Depth: ");
    Serial.print(currentDepth, 2);
    Serial.print(" adjustment: ");
    Serial.print(adjustment, 2);
    Serial.println();




}




  // 短暂延迟，以避免过快循环
  delay(10); // 延迟10毫秒
}